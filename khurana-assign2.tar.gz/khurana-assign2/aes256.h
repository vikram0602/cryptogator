#include<stdio.h>
#include<gcrypt.h>
#include<assert.h>
#include<time.h>
#include<string.h>

double timeen[100],timede[100];
int count;
static void aesTest1(int gcry_mode, char * iniVector,char * aesSymKey, char *filen)
{
    #define GCRY_CIPHER GCRY_CIPHER_AES256   // Pick the cipher here
 clock_t begin,enend,deend;
 //double time_spent,time;
 begin = clock();
 FILE * pFile;
  long lSize;int k;
  char * buffer;
  size_t result;
  char iv[16] ={0};
  char *key = "1234567890123456";
  //gcry_randomize(key,16,GCRY_STRONG_RANDOM);
  gcry_cipher_hd_t gcryCipherHd;
  pFile = fopen (filen , "r" );
  if (pFile==NULL) {fputs ("File error",stderr); exit (1);}
 FILE *f = fopen("aes256Encrypt.txt", "w");
if (f == NULL)
{
    printf("Error opening file!\n");
    exit(1);
}
FILE *f1 = fopen("aes256Decrypt.txt", "w");
if (f1 == NULL)
{
    printf("Error opening file!\n");
    exit(1);
}

  lSize = 16;
buffer = (char*) malloc (sizeof(char)*lSize);
  if (buffer == NULL) {fputs ("Memory error",stderr); exit (2);}

    gcry_error_t     gcryError;
   // gcry_cipher_hd_t gcryCipherHd;
    size_t           index;

    size_t keyLength = gcry_cipher_get_algo_keylen(GCRY_CIPHER);
    size_t blkLength = gcry_cipher_get_algo_blklen(GCRY_CIPHER);
    char * txtBuffer = "123456789 abcdefghijklmnopqrstuvwzyz ABCDEFGHIJKLMNOPQRSTUVWZYZ";
    size_t txtLength = strlen(txtBuffer)+1; // string plus termination
    char * encBuffer = malloc(txtLength);
    char * outBuffer = malloc(txtLength);
    //char * aesSymKey = "one test AES key"; // 16 bytes

    gcryError = gcry_cipher_open(
        &gcryCipherHd, // gcry_cipher_hd_t *
        GCRY_CIPHER,   // int
        gcry_mode,     // int
        0);            // unsigned int
    if (gcryError)
    {
        printf("gcry_cipher_open failed:  %s/%s\n",
               gcry_strsource(gcryError),
               gcry_strerror(gcryError));
        return;
    }

    gcryError = gcry_cipher_setkey(gcryCipherHd, aesSymKey, keyLength);
    if (gcryError)
    {
        printf("gcry_cipher_setkey failed:  %s/%s\n",
               gcry_strsource(gcryError),
               gcry_strerror(gcryError));
        return;
    }

    gcryError = gcry_cipher_setiv(gcryCipherHd, iniVector, blkLength);
    if (gcryError)
    {
        printf("gcry_cipher_setiv failed:  %s/%s\n",
               gcry_strsource(gcryError),
               gcry_strerror(gcryError));
        return;
    }

 while(!feof(pFile))
{
buffer = (char*) malloc (sizeof(char)*lSize);
  result = fread (buffer,1,lSize,pFile);
  if (result != 16) {
	  for(k=0;k<16-result;k++)
	  strcat(buffer,"0");
	  //fputs ("Reading error",stderr); exit (3);
	  }
  if(!result)
       break;
    // printf(" The Bytes Read %d \n", result);
txtBuffer =buffer;
											//printf("%s\n\n",buffer);



   gcryError = gcry_cipher_encrypt(
        gcryCipherHd, // gcry_cipher_hd_t
        encBuffer,    // void *
        txtLength,    // size_t
        txtBuffer,    // const void *
        txtLength);   // size_t
    if (gcryError)
    {
        printf("gcry_cipher_encrypt failed:  %s/%s\n",
               gcry_strsource(gcryError),
               gcry_strerror(gcryError));
        return;
    }

    if (gcryError)
    {
        printf("gcry_cipher_setiv failed:  %s/%s\n",
               gcry_strsource(gcryError),
               gcry_strerror(gcryError));
        return;
    }

    gcryError = gcry_cipher_decrypt(
        gcryCipherHd, // gcry_cipher_hd_t
        outBuffer,    // void *
        txtLength,    // size_t
        encBuffer,    // const void *
        txtLength);   // size_t
    if (gcryError)
    {
        printf("gcry_cipher_decrypt failed:  %s/%s\n",
               gcry_strsource(gcryError),
               gcry_strerror(gcryError));
        return;
    }


/* print some text */
const char *text = outBuffer;
//fprintf(f, "%s", text);

 /*
    printf("gcry_mode = %s\n", gcry_mode == GCRY_CIPHER_MODE_ECB ? "ECB" : "CBC");
    printf("keyLength = %d\n", keyLength);
    printf("blkLength = %d\n", blkLength);
    printf("txtLength = %d\n", txtLength);
    printf("aesSymKey = %s\n", aesSymKey);
    printf("iniVector = %s\n", iniVector);
    printf("txtBuffer = %s\n", txtBuffer);
 */
    //printf("encBuffer = ");
    for (index = 0; index<txtLength; index++)
    fprintf(f,"%02X", (unsigned char)encBuffer[index]);
        //fprintf(f,"%02X", encBuffer);
    //printf("\n");
    int length1=strlen(outBuffer);
  for (index = 0; index<length1-1; index++)
    fprintf(f1,"%c", outBuffer[index]);
  // fprintf(f1,"%s",outBuffer);
  //  printf("outBuffer = %s\n", outBuffer);
 //fprintf(f, "%s", text);
free (buffer);
  /* the whole file is now loaded in the memory buffer. */
}

		//printf("Encryption Time Taken: %lf \n",time_spent);
  // terminate
  fclose (pFile);


enend=clock();
		timeen[count] = (double)(enend - begin) / CLOCKS_PER_SEC;
printf("encryption and decryption time:%lf \n",timeen[count]);
    // clean up after ourselves
    gcry_cipher_close(gcryCipherHd);
    free(encBuffer);
    free(outBuffer);fclose(f); fclose(f1);


}
