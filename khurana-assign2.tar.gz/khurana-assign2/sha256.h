#include <gcrypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//#include <algorithm.h>


void hmacsha256 (const char *key, size_t keylen,char *filen)
 {
	FILE *fp;
	long len;
	char *buffer;
	int i;
	fp = fopen(filen, "rb");


	fseek(fp, 0, SEEK_END);
	len = ftell(fp);
	rewind(fp);
	buffer = (char *)malloc((len+1)*sizeof(char)); // Enough memory for file + \0
	fread(buffer,len, 1, fp); // Read in the entire file
	fclose(fp);



	   gcry_md_hd_t mdh;
	   size_t hlen = gcry_md_get_algo_dlen (GCRY_MD_SHA256);
	   unsigned char *hash;
	   gpg_error_t err;

	   err = gcry_md_open (&mdh, GCRY_MD_SHA256, GCRY_MD_FLAG_HMAC);
	  // if (err != GPG_ERR_NO_ERROR)
	  //   return GSASL_CRYPTO_ERROR;

	   err = gcry_md_setkey (mdh, key, keylen);
	   //if (err != GPG_ERR_NO_ERROR)
	    // return GSASL_CRYPTO_ERROR;

	   gcry_md_write (mdh, buffer, len);

	   hash = gcry_md_read (mdh, GCRY_MD_SHA256);
	  // if (hash == NULL)
	   //  return GSASL_CRYPTO_ERROR;
	  // out = malloc (hlen);

	  // memcpy (out, hash, hlen);
	 char *out = (char *) malloc( sizeof(char) * ((hlen*2)+1) );
  	char *p = out;
  for ( i = 0; i < hlen; i++, p += 2 ) {
    snprintf ( p, 3, "%02x", hash[i] );
  }
  printf( "%s\n", out );
  free(out);
	//free(p);
   gcry_md_close (mdh);

}
