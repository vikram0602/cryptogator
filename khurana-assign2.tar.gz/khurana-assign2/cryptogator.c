#include<stdio.h>
#include<gcrypt.h>
#include<assert.h>
#include<time.h>
#include<string.h>
#include "hmacmd5.h"
#include "sha1.h"
#include "sha256.h"

#include "aes.h"
#include "aes256.h"
#include "rsa.h"
double timeen[100],timede[100];
int count;
double calmean(double time[]){
int i,total=100;
double s=0.0;
double m;
for(i=0;i<100;i++)
s=s+time[i];

m=s/total;
return m;

}

double sortBu(double arr[])
{
	int i,j;
	double t;
	for(i=0;i<=99;i++)
	{
		for(j=0;j<99-i-1;j++)
		{
			if(arr[j]>arr[j+1])
			{
				t=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=t;
			}
		}
	}
	double median=(arr[49]+arr[50])/2;
return median;
}

double calMedian(double time[]){
//double a[100];
double median;
//a=time;
sortBu(time);
median=(time[49]+time[50])/2;
return median;

}

int main(int argc, char *argv[])
{
char ch;
	 if ( argc != 1 ) /* argc should be 1 for correct execution */
    {

        printf( "usage: %s filename", argv[1] );
    }


printf("-----------------------------AES128-------------------------\n");
int i,j;count=0;
//clock_t begin, end;
	//double time_spent[100];
	double mean,median;
char Key[16]="one test AES key";;
for(i=0;i<100;i++)
{

gcry_randomize(Key,16,GCRY_STRONG_RANDOM);
//begin = clock();
//printf("Key= %s",Key);
	 aesTest(GCRY_CIPHER_MODE_ECB, "a test ini value",Key,argv[1]);
	 count++;

	//end=clock();
		//time_spent[i] = (double)(end - begin) / CLOCKS_PER_SEC;
		//printf("Encryption Time Taken: %lf \n",time_spent[i]);
	  //aesDe(GCRY_CIPHER_MODE_ECB, "a test ini value");
}

mean=calmean(timeen);
printf("AES128 Encryption time Mean:%lf \n",mean);

median=sortBu(timeen);
printf("AES128 Encryption time Median:%lf \n",median);

/*mean=calmean(timede);
printf(" Decryption time Mean:%lf \n",mean);

median=sortBu(timede);

printf(" Decryption time Median:%lf \n",median);*/
printf("Press any key to continue and then press ENTER ");
//fflush(stdin);
scanf("%c",&ch);
printf("-----------------------------AES256-------------------------\n");
count=0;
for(i=0;i<100;i++)
{

gcry_randomize(Key,32,GCRY_STRONG_RANDOM);
//begin = clock();
//printf("Key= %s",Key);
	 aesTest1(GCRY_CIPHER_MODE_ECB, "a test ini value",Key,argv[1]);
	 count++;

	//end=clock();
		//time_spent[i] = (double)(end - begin) / CLOCKS_PER_SEC;
		//printf("Encryption Time Taken: %lf \n",time_spent[i]);
	  //aesDe(GCRY_CIPHER_MODE_ECB, "a test ini value");
}

mean=calmean(timeen);
printf(" AES256 Encryption time Mean:%lf \n",mean);

median=sortBu(timeen);
printf(" AES256 Encryption time Median:%lf \n",median);
count=0;

printf("Press any key to continue and then press ENTER ");
printf("\n\n");
scanf("%c",&ch);scanf("%c",&ch);

printf("-----------------------------MD5-------------------------\n");
i=0;
	clock_t begin, end;
	double time_spent[100];
	//double mean,median;
	//unsigned char Key[16]="one test AES key";
	for(i=0;i<100;i++)
	{
		gcry_randomize(Key,16,GCRY_STRONG_RANDOM); // Generating a 16 byte random Key
		begin = clock();
		hmacmd5(Key,sizeof(Key),argv[1]);
		end=clock();
		time_spent[i] = (double)(end - begin) / CLOCKS_PER_SEC;
		printf("Encryption Time Taken for %d iteration: %lf \n",i+1,time_spent[i]);
	}
mean=calmean(time_spent);
printf("MD5 Encryption time Mean:%lf \n",mean);
//sort(time_spent,time_spent+100);
//median=time_spent[50];
median=sortBu(time_spent);



printf(" MD5 Encryption time Median:%lf \n",median);
printf("Press any key to continue and then press ENTER ");
scanf("%c",&ch);scanf("%c",&ch);

printf("-----------------------------SHA1-------------------------\n");

for(i=0;i<100;i++)
	{
		gcry_randomize(Key,16,GCRY_STRONG_RANDOM); // Generating a 16 byte random Key
		begin = clock();
		hmacsha(Key,sizeof(Key),argv[1]);
		end=clock();
		time_spent[i] = (double)(end - begin) / CLOCKS_PER_SEC;
		printf("Encryption Time Taken for %d operation: %lf \n",i+1,time_spent[i]);
	}
mean=calmean(time_spent);
printf(" SHA1 Encryption time Mean:%lf \n",mean);
//sort(time_spent,time_spent+100);
//median=time_spent[50];
median=sortBu(time_spent);
printf("SHA1 Encryption time Median:%lf \n",median);
printf("Press any key to continue and then press ENTER ");
scanf("%c",&ch);

scanf("%c",&ch);

printf("-----------------------------SHA256-------------------------\n");

for(i=0;i<100;i++)
	{
		gcry_randomize(Key,16,GCRY_STRONG_RANDOM); // Generating a 16 byte random Key
		begin = clock();
		hmacsha256(Key,sizeof(Key),argv[1]);
		end=clock();
		time_spent[i] = (double)(end - begin) / CLOCKS_PER_SEC;
		printf("Encryption Time Taken: %lf \n",time_spent[i]);
	}
mean=calmean(time_spent);
printf("SHA256 Encryption time Mean:%lf \n",mean);
//sort(time_spent,time_spent+100);
//median=time_spent[50];
median=sortBu(time_spent);



printf(" SHA256 Encryption time Median:%lf \n",median);
printf("Press any key to continue and then press ENTER ");
scanf("%c",&ch);scanf("%c",&ch);
printf("-----------------------------RSA1024-------------------------\n");

rsaalgo(argv[1]);



}

